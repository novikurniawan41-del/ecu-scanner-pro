# ECU Scanner Pro (Flutter)

Aplikasi diagnostik OBD-II untuk Android/iOS. Kompatibilitas ditentukan oleh adapter, protokol, merek, tahun, dan dukungan ECU, bukan "semua mobil".

## Arsitektur
| Lapisan | Lokasi |
|---|---|
| User Interface | `lib/ui/` |
| Vehicle/DTC Database | `lib/data/dtc_database.dart` |
| OBD Communication Engine | `lib/core/` (`elm327.dart`, `transports/`, `pid.dart`, `dtc_decoder.dart`) |
| Diagnostic Engine | `lib/ui/app_state.dart` (scan, clear, live loop) |
| Report Generator | `lib/services/report_service.dart` |

Mode **Demo** memakai `DemoTransport` (data SIMULASI, ditandai di UI). Mode nyata memakai `BleTransport` dan hanya menampilkan data dari ECU.

## Instalasi
1. Pasang Flutter SDK 3.19+ (`flutter doctor`).
2. Di folder proyek, buat folder platform lalu ambil dependensi:
   ```
   flutter create . --project-name ecu_scanner_pro --org com.example
   flutter pub get
   ```
3. Android: tambahkan di `android/app/src/main/AndroidManifest.xml` (di dalam `<manifest>`):
   ```xml
   <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>
   <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
   <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
   <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
   <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30"/>
   ```
   Pastikan `minSdkVersion` 21 atau lebih. iOS: tambahkan `NSBluetoothAlwaysUsageDescription` di `Info.plist`.
4. Jalankan: `flutter run`. Build APK: `flutter build apk --release` (hasil di `build/app/outputs/flutter-apk/`).

## Unit test
`flutter test` (dekoder DTC, rumus PID, parser ELM327, readiness, VIN, clear DTC, timeout/koneksi terputus, protokol tidak dikenali).

## Penggunaan
1. Pasang adapter di port OBD-II, putar kunci ke ON (atau nyalakan mesin).
2. Dashboard: **Cari adapter BLE**, pilih perangkat. Atau **Mode Demo** untuk mencoba.
3. **Quick Scan** membaca DTC (confirmed, pending, permanent) dan I/M readiness. **Baca VIN** mengisi VIN dari ECU.
4. **Live Data**: Mulai/Pause, pilih sensor, lihat min/maks.
5. **DTC**: baca, cari kode atau komponen, **Hapus DTC** (ada konfirmasi dan pemeriksaan ulang).
6. **Laporan**: cetak atau bagikan PDF.

## Konfigurasi adapter
- Gunakan adapter ELM327 **BLE** (4.0) atau yang kompatibel. Adapter **Wi-Fi** didukung lewat `WifiTransport` (bawaan 192.168.0.10:35000): sambungkan HP ke Wi-Fi adapter, lalu pilih Wi-Fi OBD-II. Jika Android memakai data seluler, matikan data seluler. Adapter **Bluetooth Classic** (ELM327 murah) didukung hanya di **Android** lewat `ClassicTransport`: pasangkan dulu di Pengaturan Bluetooth (PIN 1234/0000), lalu pilih Bluetooth Classic. iOS tidak mengizinkan Bluetooth Classic untuk adapter non-MFi; gunakan adapter BLE atau Wi-Fi. Paket `flutter_blue_classic` belum saya uji; jika API-nya berbeda, hanya `classic_transport.dart` yang perlu disesuaikan.
- Klon ELM327 v2.1 murah sering tidak lengkap. Pilih adapter berchip asli atau kompatibel v1.5+.
- Jika "Protokol tidak dikenali": kunci harus ON, coba lepas-pasang adapter, atau adapter tidak cocok dengan kendaraan.

## Batasan
- Modul ABS, SRS, BCM, EPS, AC, baterai EV memerlukan protokol pabrikan (UDS/KWP khusus); belum diimplementasikan.
- Tidak ada coding/flashing ECU, immobilizer, atau penonaktifan sistem emisi/keselamatan.
- Database DTC berisi sekitar 25 kode umum; kode lain ditampilkan sebagai generik/khusus pabrikan.
- Belum ada riwayat scan permanen, ekspor CSV, dan AI mekanik di versi Flutter ini.

## Build otomatis (tanpa SDK lokal)
1. Buat repositori GitHub, unggah isi folder ini (termasuk `.github/` dan `tools/`).
2. Buka tab Actions, jalankan **Build ECU Scanner Pro** (atau push ke `main`).
3. Setelah selesai, unduh artefak `ecu-scanner-pro-apk` (file `app-release.apk`). Pindahkan ke Android, izinkan "instal dari sumber tidak dikenal", lalu instal.
4. iOS: artefak `ecu-scanner-pro-ios-unsigned` belum bertanda tangan dan tidak bisa langsung diinstal. Perlu akun Apple Developer dan Xcode (atau TestFlight) untuk menandatangani.
