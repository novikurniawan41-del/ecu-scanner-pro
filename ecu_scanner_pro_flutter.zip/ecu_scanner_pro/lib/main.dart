import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ui/app_state.dart';
import 'ui/home_page.dart';

void main() => runApp(ChangeNotifierProvider(create: (_) => AppState(), child: const EcuApp()));

class EcuApp extends StatelessWidget {
  const EcuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ECU Scanner Pro',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF0E1013),
          colorScheme: const ColorScheme.dark(primary: Color(0xFF2F7BFF), surface: Color(0xFF171A1F)),
        ),
        home: const HomePage(),
      );
}
