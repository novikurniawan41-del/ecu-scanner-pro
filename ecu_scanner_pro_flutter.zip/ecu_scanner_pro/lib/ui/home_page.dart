import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import '../core/transports/classic_transport.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import '../core/pid.dart';
import '../data/dtc_database.dart';
import '../services/report_service.dart';
import 'app_state.dart';

const kOk = Color(0xFF2ECC71), kWarn = Color(0xFFF5C542), kErr = Color(0xFFFF4D4F);

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    const pages = [DashboardTab(), LiveTab(), DtcTab(), ReportTab()];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ECU SCANNER PRO'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: Text(s.status, style: TextStyle(fontSize: 12, color: s.demo ? kWarn : s.connected ? kOk : Colors.grey))),
          )
        ],
        bottom: s.busy ? const PreferredSize(preferredSize: Size.fromHeight(2), child: LinearProgressIndicator()) : null,
      ),
      body: Column(children: [
        if (s.demo) Container(width: double.infinity, color: const Color(0xFF2B2410), padding: const EdgeInsets.all(6), child: const Text('Data SIMULASI. Bukan data kendaraan nyata.', textAlign: TextAlign.center, style: TextStyle(color: kWarn, fontSize: 12))),
        if (s.error != null) Container(width: double.infinity, color: const Color(0xFF3A1416), padding: const EdgeInsets.all(8), child: Text(s.error!, style: const TextStyle(color: kErr))),
        Expanded(child: pages[tab]),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.speed), label: 'Live Data'),
          NavigationDestination(icon: Icon(Icons.warning_amber), label: 'DTC'),
          NavigationDestination(icon: Icon(Icons.description), label: 'Laporan'),
        ],
      ),
    );
  }
}

class DashboardTab extends StatelessWidget {
  const DashboardTab({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return ListView(padding: const EdgeInsets.all(12), children: [
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Koneksi adapter', style: TextStyle(fontWeight: FontWeight.bold)),
        if (s.connected) Text('${s.client!.protocol} · ${s.client!.voltage}'),
        const SizedBox(height: 8),
        Wrap(spacing: 8, children: [
          FilledButton(onPressed: s.busy ? null : () => showModalBottomSheet(context: context, builder: (_) => const ScanSheet()), child: const Text('Cari adapter BLE')),
          if (Platform.isAndroid) OutlinedButton(onPressed: s.busy ? null : () => showModalBottomSheet(context: context, builder: (_) => const ClassicSheet()), child: const Text('Bluetooth Classic')),
          OutlinedButton(onPressed: s.busy ? null : () => _wifi(context, s), child: const Text('Wi-Fi OBD-II')),
          OutlinedButton(onPressed: s.busy ? null : s.connectDemo, child: const Text('Mode Demo')),
          if (s.connected) TextButton(onPressed: s.disconnect, child: const Text('Putuskan')),
        ]),
      ]))),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        _field(s, 'brand', 'Merek (mis. Toyota)'), _field(s, 'model', 'Model'), _field(s, 'year', 'Tahun'), _field(s, 'engine', 'Mesin / kapasitas'),
        Align(alignment: Alignment.centerLeft, child: Text('VIN: ${s.vin ?? '-'}')),
        TextButton(onPressed: s.connected && !s.busy ? s.readVin : null, child: const Text('Baca VIN dari ECU')),
      ]))),
      FilledButton.icon(onPressed: s.connected && !s.busy ? s.quickScan : null, icon: const Icon(Icons.search), label: const Text('QUICK SCAN')),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: _count('Confirmed', s.confirmed.length)),
        Expanded(child: _count('Pending', s.pending.length)),
        Expanded(child: _count('Permanent', s.permanent.length)),
      ]),
      const Padding(padding: EdgeInsets.all(8), child: Text('Modul selain mesin (ABS, SRS, BCM) umumnya tidak dapat dibaca lewat OBD-II standar dan memerlukan protokol pabrikan.', style: TextStyle(fontSize: 12, color: Colors.grey))),
    ]);
  }

  Future<void> _wifi(BuildContext context, AppState s) async {
    final h = TextEditingController(text: '192.168.0.10'), p = TextEditingController(text: '35000');
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Adapter Wi-Fi'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Sambungkan HP ke jaringan Wi-Fi adapter terlebih dahulu.', style: TextStyle(fontSize: 12)),
        TextField(controller: h, decoration: const InputDecoration(labelText: 'IP')),
        TextField(controller: p, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Port')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Hubungkan'))]));
    if (ok == true) s.connectWifi(h.text.trim(), int.tryParse(p.text) ?? 35000);
  }

  Widget _field(AppState s, String k, String hint) => TextField(
        decoration: InputDecoration(labelText: hint), controller: TextEditingController(text: s.vehicle[k]),
        onChanged: (v) => s.vehicle[k] = v);
  Widget _count(String l, int n) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        Text('$n', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: n > 0 ? kErr : kOk)), Text(l, style: const TextStyle(fontSize: 12))])));
}

class ScanSheet extends StatefulWidget {
  const ScanSheet({super.key});
  @override
  State<ScanSheet> createState() => _ScanSheetState();
}

class _ScanSheetState extends State<ScanSheet> {
  @override
  void initState() {
    super.initState();
    FlutterBluePlus.startScan(timeout: const Duration(seconds: 8));
  }

  @override
  Widget build(BuildContext context) => StreamBuilder<List<ScanResult>>(
        stream: FlutterBluePlus.scanResults,
        initialData: const [],
        builder: (c, snap) {
          final r = snap.data!;
          if (r.isEmpty) return const Center(child: Text('Mencari perangkat BLE...'));
          return ListView(children: [
            for (final e in r)
              ListTile(
                title: Text(e.device.platformName.isEmpty ? e.device.remoteId.str : e.device.platformName),
                subtitle: Text('RSSI ${e.rssi}'),
                onTap: () { Navigator.pop(context); context.read<AppState>().connectBle(e.device); },
              )
          ]);
        },
      );
}

class ClassicSheet extends StatelessWidget {
  const ClassicSheet({super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<(String, String)>>(
        future: bondedAdapters(),
        builder: (c, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final l = snap.data!;
          if (l.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(16), child: Text('Belum ada perangkat terpasang. Pasangkan adapter di Pengaturan Bluetooth Android (PIN 1234 atau 0000), lalu buka lagi.')));
          return ListView(children: [
            for (final d in l)
              ListTile(title: Text(d.$1), subtitle: Text(d.$2), onTap: () { Navigator.pop(context); context.read<AppState>().connectClassic(d.$2); }),
          ]);
        },
      );
}

class LiveTab extends StatelessWidget {
  const LiveTab({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return ListView(padding: const EdgeInsets.all(12), children: [
      FilledButton(onPressed: s.toggleLive, child: Text(s.live ? 'Pause' : 'Mulai / Resume')),
      ExpansionTile(title: const Text('Pilih sensor'), children: [
        for (final p in allPids) CheckboxListTile(dense: true, value: s.selected.contains(p.id), title: Text(p.name), onChanged: (_) => s.toggleSel(p.id))
      ]),
      for (final p in allPids.where((p) => s.selected.contains(p.id))) _tile(s, p),
    ]);
  }

  Widget _tile(AppState s, Pid p) {
    final v = s.values[p.id];
    final col = v == null ? Colors.grey : (p.crit != null && v >= p.crit!) ? kErr : (p.warn != null && v >= p.warn!) ? kWarn : kOk;
    return Card(child: ListTile(
      title: Text(p.name),
      subtitle: Text(v == null ? 'min -- · maks --' : 'min ${s.minV[p.id]!.toStringAsFixed(1)} · maks ${s.maxV[p.id]!.toStringAsFixed(1)}'),
      trailing: Text(v == null ? '--' : '${v.toStringAsFixed(1)} ${p.unit}', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: col)),
    ));
  }
}

class DtcTab extends StatefulWidget {
  const DtcTab({super.key});
  @override
  State<DtcTab> createState() => _DtcTabState();
}

class _DtcTabState extends State<DtcTab> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final all = [...s.confirmed.map((c) => (c, 'Confirmed')), ...s.pending.map((c) => (c, 'Pending')), ...s.permanent.map((c) => (c, 'Permanent'))];
    return ListView(padding: const EdgeInsets.all(12), children: [
      Row(children: [
        Expanded(child: FilledButton(onPressed: s.connected && !s.busy ? s.quickScan : null, child: const Text('Baca DTC'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton(onPressed: s.connected && !s.busy ? () => _clear(context, s) : null, child: const Text('Hapus DTC'))),
      ]),
      TextField(decoration: const InputDecoration(labelText: 'Cari kode atau komponen'), onChanged: (v) => setState(() => q = v)),
      for (final d in searchDtc(q).take(8)) _card(d, 'Referensi'),
      if (all.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Tidak ada DTC terbaca.')),
      for (final e in all) _card(lookupDtc(e.$1), e.$2),
      if (s.readiness.isNotEmpty) ...[
        const Padding(padding: EdgeInsets.only(top: 12), child: Text('I/M Readiness', style: TextStyle(fontWeight: FontWeight.bold))),
        for (final e in s.readiness.entries) Text('${e.key}: ${e.value}', style: TextStyle(color: e.value == 'Ready' ? kOk : e.value == 'Not Ready' ? kWarn : Colors.grey)),
      ],
    ]);
  }

  Widget _card(DtcInfo d, String t) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${d.code}  ·  $t  ·  Prioritas ${d.priorityLabel}', style: TextStyle(fontWeight: FontWeight.bold, color: d.priority == 3 ? kErr : d.priority == 2 ? kWarn : kOk)),
        Text(d.name),
        Text('Penyebab: ${d.causes}\nGejala: ${d.symptoms}\nPeriksa: ${d.parts}\nRisiko: ${d.risk}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ])));

  Future<void> _clear(BuildContext context, AppState s) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Hapus DTC?'),
      content: const Text('Menghapus DTC juga mereset freeze frame dan status readiness. Penyebab kerusakan TIDAK diperbaiki. DTC permanen tidak dapat dihapus.'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Hapus'))]));
    if (ok != true) return;
    final clean = await s.clearDtc();
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(clean ? 'Berhasil: tidak ada DTC tersisa.' : 'Sebagian kode masih ada (permanen atau penyebab belum hilang).')));
  }
}

class ReportTab extends StatelessWidget {
  const ReportTab({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return ListView(padding: const EdgeInsets.all(12), children: [
      Text('Kendaraan: ${s.vehicle['brand'] ?? '-'} ${s.vehicle['model'] ?? ''}\nVIN: ${s.vin ?? '-'}\nWaktu scan: ${s.scanTime ?? 'belum ada scan'}\nDTC: ${[...s.confirmed, ...s.pending, ...s.permanent].join(', ')}'),
      const SizedBox(height: 12),
      FilledButton(onPressed: s.scanTime == null ? null : () => Printing.layoutPdf(onLayout: (_) => ReportService.buildPdf(s)), child: const Text('Cetak / Bagikan PDF')),
      const Padding(padding: EdgeInsets.only(top: 8), child: Text('Laporan tidak dikirim ke server mana pun. PDF dapat dibagikan lewat WhatsApp atau email dari menu bagikan.', style: TextStyle(fontSize: 12, color: Colors.grey))),
    ]);
  }
}
