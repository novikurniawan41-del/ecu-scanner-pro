import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import '../core/elm327.dart';
import '../core/pid.dart';
import '../core/transport.dart';
import '../core/transports/ble_transport.dart';
import '../core/transports/classic_transport.dart';
import '../core/transports/demo_transport.dart';
import '../core/transports/wifi_transport.dart';

class AppState extends ChangeNotifier {
  Elm327Client? client;
  ObdTransport? _tr;
  bool demo = false, connected = false, live = false, busy = false;
  String? error, vin;
  DateTime? scanTime;
  final selected = <String>{'0C', '0D', '05', '11', '04', '42'};
  final values = <String, double>{};
  final minV = <String, double>{}, maxV = <String, double>{};
  List<String> confirmed = [], pending = [], permanent = [];
  Map<String, String> readiness = {};
  final vehicle = <String, String>{};

  String get status => !connected ? 'Belum terhubung' : demo ? 'MODE DEMO (SIMULASI)' : 'Terhubung ${client?.protocol ?? ''}';

  Future<void> _run(Future<void> Function() f) async {
    busy = true; error = null; notifyListeners();
    try { await f(); } catch (e) { error = e.toString(); }
    busy = false; notifyListeners();
  }

  Future<void> connectDemo() => _run(() async {
        await disconnect();
        _tr = DemoTransport();
        await _start(true);
      });

  Future<void> connectBle(BluetoothDevice d) => _run(() async {
        await disconnect();
        await FlutterBluePlus.stopScan();
        final t = BleTransport(d)..onLost = _lost;
        _tr = t;
        await t.open();
        await _start(false);
      });

  Future<void> connectClassic(String address) => _run(() async {
        await disconnect();
        final t = ClassicTransport(address)..onLost = _lost;
        _tr = t;
        await t.open();
        await _start(false);
      });

  Future<void> connectWifi(String host, int port) => _run(() async {
        await disconnect();
        final t = WifiTransport(host: host, port: port)..onLost = _lost;
        _tr = t;
        await t.open();
        await _start(false);
      });

  Future<void> _start(bool isDemo) async {
    final c = Elm327Client(_tr!);
    await c.init();
    client = c; demo = isDemo; connected = true;
  }

  void _lost() {
    connected = false; live = false;
    error = 'Koneksi terputus. Periksa adapter lalu sambungkan ulang.';
    notifyListeners();
  }

  Future<void> disconnect() async {
    live = false;
    try { await _tr?.close(); } catch (_) {}
    connected = false; client = null; _tr = null;
    notifyListeners();
  }

  Future<void> quickScan() => _run(() async {
        final c = _need();
        confirmed = await c.readDtc('03');
        pending = await c.readDtc('07');
        permanent = await c.readDtc('0A').catchError((_) => <String>[]);
        try { readiness = await c.readReadiness(); } catch (_) {}
        scanTime = DateTime.now();
      });

  Future<void> readVin() => _run(() async { vin = await _need().readVin(); });

  /// Mengembalikan true bila tidak ada DTC confirmed/permanent tersisa.
  Future<bool> clearDtc() async {
    var ok = false;
    await _run(() async {
      final c = _need();
      await c.clearDtc();
      confirmed = await c.readDtc('03');
      permanent = await c.readDtc('0A').catchError((_) => <String>[]);
      ok = confirmed.isEmpty && permanent.isEmpty;
    });
    return ok;
  }

  void toggleLive() {
    if (live) { live = false; notifyListeners(); return; }
    if (!connected) { error = 'Hubungkan adapter atau aktifkan Mode Demo.'; notifyListeners(); return; }
    live = true; notifyListeners(); _loop();
  }

  Future<void> _loop() async {
    while (live && connected) {
      for (final p in allPids.where((p) => selected.contains(p.id))) {
        if (!live) break;
        try {
          final v = await client!.readPid(p);
          if (v == null) continue;
          values[p.id] = v;
          minV[p.id] = minV.containsKey(p.id) ? (v < minV[p.id]! ? v : minV[p.id]!) : v;
          maxV[p.id] = maxV.containsKey(p.id) ? (v > maxV[p.id]! ? v : maxV[p.id]!) : v;
        } catch (e) { error = e.toString(); }
      }
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 150));
    }
  }

  void toggleSel(String id) { selected.contains(id) ? selected.remove(id) : selected.add(id); notifyListeners(); }
  Elm327Client _need() { if (!connected || client == null) throw StateError('Belum terhubung ke adapter.'); return client!; }
}
