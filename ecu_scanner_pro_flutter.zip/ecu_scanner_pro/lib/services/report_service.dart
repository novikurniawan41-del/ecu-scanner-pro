import 'dart:typed_data';
import 'package:pdf/widgets.dart' as pw;
import '../data/dtc_database.dart';
import '../ui/app_state.dart';
import '../core/pid.dart';

class ReportService {
  static Future<Uint8List> buildPdf(AppState s) async {
    final doc = pw.Document();
    final v = s.vehicle;
    doc.addPage(pw.MultiPage(build: (_) => [
          pw.Header(level: 0, text: 'Laporan ECU Scanner Pro${s.demo ? ' (SIMULASI)' : ''}'),
          pw.Text('Kendaraan: ${v['brand'] ?? '-'} ${v['model'] ?? ''} ${v['year'] ?? ''}'),
          pw.Text('VIN: ${s.vin ?? '-'}'),
          pw.Text('Waktu scan: ${s.scanTime ?? '-'}'),
          pw.Text('Perangkat: ${s.connected ? s.client!.protocol : '-'}'),
          pw.Header(level: 1, text: 'DTC'),
          if (s.confirmed.isEmpty && s.pending.isEmpty && s.permanent.isEmpty) pw.Text('Tidak ada DTC.'),
          for (final e in [
            ...s.confirmed.map((c) => ['Confirmed', c]),
            ...s.pending.map((c) => ['Pending', c]),
            ...s.permanent.map((c) => ['Permanent', c]),
          ])
            pw.Bullet(text: '${e[1]} (${e[0]}) - ${lookupDtc(e[1]).name}'),
          pw.Header(level: 1, text: 'I/M Readiness'),
          for (final e in s.readiness.entries) pw.Text('${e.key}: ${e.value}'),
          pw.Header(level: 1, text: 'Live data terakhir'),
          for (final p in allPids.where((p) => s.values.containsKey(p.id)))
            pw.Text('${p.name}: ${s.values[p.id]!.toStringAsFixed(1)} ${p.unit}'),
          pw.SizedBox(height: 12),
          pw.Text('Catatan: laporan ini bukan diagnosis pasti. Lakukan pemeriksaan fisik sebelum mengganti komponen.'),
        ]));
    return doc.save();
  }
}
