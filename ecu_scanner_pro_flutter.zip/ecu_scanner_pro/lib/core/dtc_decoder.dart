/// Dekode pasangan byte DTC (SAE J2012) menjadi kode seperti P0300.
class DtcDecoder {
  static const _cat = ['P', 'C', 'B', 'U'];

  static List<String> decode(List<int> bytes) {
    final out = <String>[];
    for (var i = 0; i + 1 < bytes.length; i += 2) {
      final a = bytes[i], b = bytes[i + 1];
      if (a == 0 && b == 0) continue; // padding
      out.add('${_cat[a >> 6]}${(a >> 4) & 3}'
          '${(a & 15).toRadixString(16).toUpperCase()}'
          '${b.toRadixString(16).toUpperCase().padLeft(2, '0')}');
    }
    return out;
  }

  static String categoryName(String code) {
    switch (code[0]) {
      case 'P':
        return 'Powertrain';
      case 'B':
        return 'Body';
      case 'C':
        return 'Chassis';
      default:
        return 'Jaringan';
    }
  }

  /// true bila kode khusus pabrikan (digit kedua 1/3 untuk P; 1-3 untuk B/C/U).
  static bool isManufacturerSpecific(String code) {
    final d = code[1];
    if (code[0] == 'P') return d == '1' || d == '3';
    return d == '1' || d == '2' || d == '3';
  }
}
