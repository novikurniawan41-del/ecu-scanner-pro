class Pid {
  final String id, name, unit;
  final int bytes;
  final double Function(List<int>) decode;
  final double? warn, crit;
  const Pid(this.id, this.name, this.unit, this.bytes, this.decode, {this.warn, this.crit});
  String get request => '01$id';
  String get prefix => '41$id';
}

double _w(List<int> b) => (b[0] * 256 + b[1]).toDouble();

final List<Pid> allPids = [
  Pid('0C', 'RPM Mesin', 'rpm', 2, (b) => _w(b) / 4, warn: 6000, crit: 7000),
  Pid('0D', 'Kecepatan', 'km/h', 1, (b) => b[0].toDouble()),
  Pid('05', 'Suhu Coolant', '°C', 1, (b) => b[0] - 40.0, warn: 105, crit: 115),
  Pid('0F', 'Suhu Udara Masuk', '°C', 1, (b) => b[0] - 40.0),
  Pid('11', 'Posisi Throttle', '%', 1, (b) => b[0] * 100 / 255),
  Pid('04', 'Beban Mesin', '%', 1, (b) => b[0] * 100 / 255),
  Pid('10', 'MAF', 'g/s', 2, (b) => _w(b) / 100),
  Pid('0B', 'MAP', 'kPa', 1, (b) => b[0].toDouble()),
  Pid('06', 'Short Term Fuel Trim', '%', 1, (b) => (b[0] - 128) * 100 / 128, warn: 15, crit: 25),
  Pid('07', 'Long Term Fuel Trim', '%', 1, (b) => (b[0] - 128) * 100 / 128, warn: 15, crit: 25),
  Pid('0E', 'Timing Advance', '°', 1, (b) => b[0] / 2 - 64),
  Pid('42', 'Tegangan Modul', 'V', 2, (b) => _w(b) / 1000),
  Pid('0A', 'Tekanan Bahan Bakar', 'kPa', 1, (b) => b[0] * 3.0),
  Pid('49', 'Pedal Akselerator', '%', 1, (b) => b[0] * 100 / 255),
  Pid('34', 'AFR (dari lambda)', ':1', 2, (b) => _w(b) * 2 / 65536 * 14.7),
  Pid('78', 'Suhu Exhaust', '°C', 2, (b) => _w(b) / 10 - 40),
];
