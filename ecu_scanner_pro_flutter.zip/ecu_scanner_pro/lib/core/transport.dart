/// Abstraksi jalur komunikasi ke adapter ELM327.
abstract class ObdTransport {
  Future<void> open();
  Future<void> close();

  /// Kirim perintah, kembalikan respons mentah (tanpa karakter prompt '>').
  Future<String> send(String command, {Duration timeout = const Duration(seconds: 5)});
  void Function()? onLost;
}
