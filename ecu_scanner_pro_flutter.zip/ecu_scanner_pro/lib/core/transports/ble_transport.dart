import 'dart:async';
import 'dart:convert';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import '../obd_exception.dart';
import '../transport.dart';

/// Transport adapter ELM327 BLE. Adapter Bluetooth Classic tidak didukung paket ini.
class BleTransport implements ObdTransport {
  final BluetoothDevice device;
  BluetoothCharacteristic? _w;
  StreamSubscription? _sub, _conn;
  final _buf = StringBuffer();
  Completer<String>? _c;
  @override
  void Function()? onLost;
  BleTransport(this.device);

  @override
  Future<void> open() async {
    await device.connect(timeout: const Duration(seconds: 12));
    BluetoothCharacteristic? r, w;
    for (final s in await device.discoverServices()) {
      for (final c in s.characteristics) {
        if (c.properties.notify && r == null) r = c;
        if ((c.properties.write || c.properties.writeWithoutResponse) && w == null) w = c;
      }
    }
    if (r == null || w == null) throw ObdException('Perangkat bukan adapter BLE ELM327.');
    await r.setNotifyValue(true);
    _sub = r.onValueReceived.listen((v) {
      _buf.write(utf8.decode(v, allowMalformed: true));
      final s = _buf.toString();
      if (s.contains('>')) {
        _buf.clear();
        _c?.complete(s.replaceAll('>', ''));
        _c = null;
      }
    });
    _conn = device.connectionState.listen((st) {
      if (st == BluetoothConnectionState.disconnected) onLost?.call();
    });
    _w = w;
  }

  @override
  Future<String> send(String command, {Duration timeout = const Duration(seconds: 5)}) async {
    _buf.clear();
    final c = _c = Completer<String>();
    await _w!.write(utf8.encode('$command\r'), withoutResponse: _w!.properties.writeWithoutResponse);
    return c.future.timeout(timeout, onTimeout: () {
      _c = null;
      throw ObdException('Timeout menunggu respons: $command');
    });
  }

  @override
  Future<void> close() async {
    await _sub?.cancel();
    await _conn?.cancel();
    await device.disconnect();
  }
}
