import 'dart:math';
import '../transport.dart';

/// Transport SIMULASI untuk Mode Demo. Semua data BUKAN dari kendaraan nyata.
class DemoTransport implements ObdTransport {
  @override
  void Function()? onLost;
  final _t0 = DateTime.now();
  @override
  Future<void> open() async {}
  @override
  Future<void> close() async {}

  String _h(List<int> b) => b.map((e) => e.toRadixString(16).toUpperCase().padLeft(2, '0')).join(' ');

  @override
  Future<String> send(String c, {Duration timeout = const Duration(seconds: 5)}) async {
    final s = DateTime.now().difference(_t0).inMilliseconds / 1000;
    final k = sin(s / 3).abs();
    final rpm4 = ((850 + k * 2200) * 4).toInt();
    switch (c) {
      case 'ATDP':
        return 'ISO 15765-4 (CAN 11/500) [SIMULASI]';
      case 'ATRV':
        return '14.1V';
      case '0100':
        return '41 00 BE 3E B8 11';
      case '010C':
        return '41 0C ${_h([rpm4 ~/ 256, rpm4 % 256])}';
      case '010D':
        return '41 0D ${_h([(k * 60).toInt()])}';
      case '0105':
        return '41 05 ${_h([128])}';
      case '010F':
        return '41 0F ${_h([74])}';
      case '0111':
        return '41 11 ${_h([(k * 80 + 30).toInt()])}';
      case '0104':
        return '41 04 ${_h([(k * 90 + 60).toInt()])}';
      case '0106':
        return '41 06 ${_h([128 + (sin(s) * 6).toInt()])}';
      case '0107':
        return '41 07 ${_h([130])}';
      case '0142':
        return '41 42 37 E4';
      case '03':
        return '43 02 01 71 03 00 00';
      case '07':
        return '47 01 04 20 00 00 00';
      case '0A':
        return '4A 00';
      case '04':
        return '44';
      case '0101':
        return '41 01 82 07 E5 04';
      case '0902':
        return '014\r0: 49 02 01 53 49 4D\r1: 55 4C 41 53 49 30 30\r2: 30 30 30 30 30 30 31';
      default:
        return c.startsWith('AT') ? 'OK' : 'NO DATA';
    }
  }
}
