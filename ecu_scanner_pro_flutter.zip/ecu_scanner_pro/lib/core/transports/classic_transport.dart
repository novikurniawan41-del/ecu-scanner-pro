import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_blue_classic/flutter_blue_classic.dart';
import '../obd_exception.dart';
import '../transport.dart';

/// Transport adapter ELM327 Bluetooth Classic (SPP). Hanya Android.
/// Perangkat harus sudah dipasangkan (pairing) di Pengaturan Bluetooth; PIN umum 1234 atau 0000.
class ClassicTransport implements ObdTransport {
  final String address;
  BluetoothConnection? _conn;
  StreamSubscription? _sub;
  final _buf = StringBuffer();
  Completer<String>? _c;
  @override
  void Function()? onLost;
  ClassicTransport(this.address);

  @override
  Future<void> open() async {
    try {
      _conn = await FlutterBlueClassic().connect(address);
    } catch (_) {
      _conn = null;
    }
    final input = _conn?.input;
    if (input == null) {
      throw ObdException('Tidak dapat terhubung ke adapter. Pastikan sudah dipasangkan dan berada dalam jangkauan.');
    }
    _sub = input.listen((Uint8List d) {
      _buf.write(utf8.decode(d, allowMalformed: true));
      final s = _buf.toString();
      if (s.contains('>')) {
        _buf.clear();
        _c?.complete(s.replaceAll('>', ''));
        _c = null;
      }
    }, onDone: () => onLost?.call(), onError: (_) => onLost?.call());
  }

  @override
  Future<String> send(String command, {Duration timeout = const Duration(seconds: 5)}) {
    _buf.clear();
    final c = _c = Completer<String>();
    _conn!.output.add(Uint8List.fromList(utf8.encode('$command\r')));
    return c.future.timeout(timeout, onTimeout: () {
      _c = null;
      throw ObdException('Timeout menunggu respons: $command');
    });
  }

  @override
  Future<void> close() async {
    await _sub?.cancel();
    _conn?.dispose();
  }
}

/// Daftar adapter yang sudah dipasangkan: (nama, alamat).
Future<List<(String, String)>> bondedAdapters() async {
  final l = await FlutterBlueClassic().bondedDevices ?? [];
  return [for (final d in l) (d.name ?? d.address, d.address)];
}
