import 'dart:async';
import 'dart:convert';
import 'dart:io';
import '../obd_exception.dart';
import '../transport.dart';

/// Transport adapter ELM327 Wi-Fi (TCP). Bawaan umum: 192.168.0.10:35000.
class WifiTransport implements ObdTransport {
  final String host;
  final int port;
  Socket? _s;
  StreamSubscription? _sub;
  final _buf = StringBuffer();
  Completer<String>? _c;
  @override
  void Function()? onLost;
  WifiTransport({this.host = '192.168.0.10', this.port = 35000});

  @override
  Future<void> open() async {
    try {
      _s = await Socket.connect(host, port, timeout: const Duration(seconds: 6));
    } catch (_) {
      throw ObdException('Tidak dapat terhubung ke $host:$port. Pastikan HP tersambung ke Wi-Fi adapter.');
    }
    _sub = _s!.listen((d) {
      _buf.write(utf8.decode(d, allowMalformed: true));
      final s = _buf.toString();
      if (s.contains('>')) {
        _buf.clear();
        _c?.complete(s.replaceAll('>', ''));
        _c = null;
      }
    }, onDone: () => onLost?.call(), onError: (_) => onLost?.call());
  }

  @override
  Future<String> send(String command, {Duration timeout = const Duration(seconds: 5)}) {
    _buf.clear();
    final c = _c = Completer<String>();
    _s!.add(utf8.encode('$command\r'));
    return c.future.timeout(timeout, onTimeout: () {
      _c = null;
      throw ObdException('Timeout menunggu respons: $command');
    });
  }

  @override
  Future<void> close() async {
    await _sub?.cancel();
    await _s?.close();
  }
}
