class ObdException implements Exception {
  final String message;
  ObdException(this.message);
  @override
  String toString() => message;
}
