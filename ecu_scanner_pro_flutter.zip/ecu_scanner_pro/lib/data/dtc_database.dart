import '../core/dtc_decoder.dart';

class DtcInfo {
  final String code, name, causes, symptoms, parts;
  final int priority; // 1 rendah, 2 sedang, 3 tinggi
  const DtcInfo(this.code, this.name, this.causes, this.symptoms, this.priority, this.parts);

  String get priorityLabel => const ['', 'Rendah', 'Sedang', 'Tinggi'][priority];
  String get risk => priority == 3
      ? 'Dapat merusak mesin atau komponen lain. Hindari berkendara jauh.'
      : priority == 2
          ? 'Boros, performa turun, kerusakan bertahap.'
          : 'Emisi naik, risiko rendah.';
}

const _d = <DtcInfo>[
  DtcInfo('P0100', 'Sirkuit MAF bermasalah', 'Konektor longgar, MAF kotor, kabel putus', 'Brebet, tarikan berat', 2, 'MAF, konektor, filter udara'),
  DtcInfo('P0101', 'MAF di luar rentang', 'Kebocoran intake, MAF kotor, filter tersumbat', 'Boros, tenaga turun', 2, 'MAF, selang intake'),
  DtcInfo('P0105', 'Sirkuit MAP bermasalah', 'Selang vakum bocor, sensor MAP rusak, kabel', 'Idle kasar, boros', 2, 'MAP, selang vakum'),
  DtcInfo('P0113', 'Suhu udara masuk terlalu tinggi', 'Sensor IAT rusak, kabel short', 'Campuran kurang pas', 1, 'IAT, konektor'),
  DtcInfo('P0117', 'Sensor suhu coolant rendah', 'ECT short, kabel', 'Kipas selalu nyala', 2, 'ECT, wiring'),
  DtcInfo('P0118', 'Sensor suhu coolant tinggi', 'ECT open, konektor', 'Idle tinggi, sulit hidup', 2, 'ECT, konektor'),
  DtcInfo('P0120', 'Sirkuit TPS bermasalah', 'TPS aus, kabel, konektor', 'Tarikan tersendat', 2, 'TPS, throttle body'),
  DtcInfo('P0130', 'Sirkuit O2 sensor B1S1', 'Sensor menua, kabel panas, kebocoran exhaust', 'Boros, emisi tinggi', 2, 'O2 sensor, wiring'),
  DtcInfo('P0171', 'Campuran terlalu kurus (Bank 1)', 'Kebocoran vakum, MAF kotor, tekanan BBM rendah, injektor mampet', 'Idle kasar, tarikan lemah', 2, 'Selang intake, MAF, pompa BBM, injektor'),
  DtcInfo('P0172', 'Campuran terlalu kaya (Bank 1)', 'Injektor bocor, MAF kotor, tekanan BBM tinggi', 'Boros, asap hitam', 2, 'Injektor, MAF, regulator BBM'),
  DtcInfo('P0174', 'Campuran terlalu kurus (Bank 2)', 'Kebocoran vakum, MAF, injektor bank 2', 'Idle kasar', 2, 'Intake, MAF, injektor'),
  DtcInfo('P0300', 'Misfire acak / multi silinder', 'Busi aus, koil, kompresi, kebocoran vakum, BBM buruk', 'Getar, MIL berkedip, tenaga turun', 3, 'Busi, koil, injektor, kompresi'),
  DtcInfo('P0335', 'Sirkuit sensor CKP bermasalah', 'Sensor CKP, kabel, celah sensor', 'Mesin mati mendadak, sulit hidup', 3, 'CKP, konektor'),
  DtcInfo('P0340', 'Sirkuit sensor CMP bermasalah', 'Sensor CMP, kabel, timing bergeser', 'Sulit hidup, brebet', 3, 'CMP, timing'),
  DtcInfo('P0420', 'Efisiensi katalis di bawah ambang', 'Katalis menua, O2 belakang, kebocoran exhaust, misfire lama', 'Biasanya tanpa gejala', 1, 'Katalis, O2 sensor, exhaust'),
  DtcInfo('P0440', 'Sistem EVAP bermasalah', 'Tutup tangki longgar, selang EVAP, purge valve', 'Biasanya tanpa gejala', 1, 'Tutup tangki, purge valve'),
  DtcInfo('P0442', 'Kebocoran kecil EVAP', 'Tutup tangki, selang retak', 'Bau bensin ringan', 1, 'Tutup tangki, selang'),
  DtcInfo('P0455', 'Kebocoran besar EVAP', 'Tutup tangki hilang, selang lepas', 'Bau bensin', 1, 'Tutup tangki, canister'),
  DtcInfo('P0500', 'Sensor kecepatan kendaraan', 'VSS, kabel, sensor ABS', 'Speedometer mati, pindah gigi kasar', 2, 'VSS, wiring'),
  DtcInfo('P0505', 'Kontrol idle bermasalah', 'Throttle body kotor, IAC, kebocoran vakum', 'Idle naik turun', 2, 'Throttle body, IAC'),
  DtcInfo('P0562', 'Tegangan sistem rendah', 'Aki lemah, alternator, massa', 'Lampu redup, ECU reset', 2, 'Aki, alternator, massa'),
  DtcInfo('U0100', 'Komunikasi dengan ECM/PCM hilang', 'Kabel CAN, ECU, sekring, aki lemah', 'Banyak lampu peringatan', 3, 'Jalur CAN, sekring, ECU'),
];

final Map<String, DtcInfo> dtcDatabase = {for (final e in _d) e.code: e};

DtcInfo lookupDtc(String code) {
  final hit = dtcDatabase[code];
  if (hit != null) return hit;
  final m = RegExp(r'^P030([1-9])$').firstMatch(code);
  if (m != null) {
    final n = m.group(1);
    return DtcInfo(code, 'Misfire silinder $n', 'Busi, koil, injektor, kompresi silinder $n', 'Getar, tenaga turun', 3, 'Busi, koil, injektor silinder $n');
  }
  final tag = DtcDecoder.isManufacturerSpecific(code) ? 'Kode khusus pabrikan' : 'Kode generik';
  return DtcInfo(code, '$tag (tidak ada di database lokal)', 'Lihat manual servis kendaraan', 'Bervariasi', 2, 'Sesuai manual pabrikan');
}

List<DtcInfo> searchDtc(String q) {
  final s = q.trim().toUpperCase();
  if (s.isEmpty) return [];
  return dtcDatabase.values
      .where((e) => e.code.contains(s) || e.name.toUpperCase().contains(s) || e.parts.toUpperCase().contains(s))
      .toList();
}
