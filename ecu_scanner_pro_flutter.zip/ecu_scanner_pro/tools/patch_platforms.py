"""Tambahkan izin Bluetooth ke Android/iOS setelah `flutter create .`"""
import pathlib, re
m = pathlib.Path('android/app/src/main/AndroidManifest.xml')
if m.exists():
    s = m.read_text()
    if 'BLUETOOTH_SCAN' not in s:
        perms = ('<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>\n'
                 '    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>\n'
                 '    <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>\n'
                 '    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>\n'
                 '    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="30"/>\n    ')
        s = s.replace('<application', perms + '<application', 1)
        m.write_text(s)
p = pathlib.Path('ios/Runner/Info.plist')
if p.exists():
    s = p.read_text()
    if 'NSBluetoothAlwaysUsageDescription' not in s:
        s = s.replace('</dict>', '\t<key>NSLocalNetworkUsageDescription</key>\n\t<string>Dipakai untuk terhubung ke adapter OBD-II Wi-Fi.</string>\n\t<key>NSBluetoothAlwaysUsageDescription</key>\n\t<string>Dipakai untuk terhubung ke adapter OBD-II.</string>\n</dict>', 1)
        p.write_text(s)
