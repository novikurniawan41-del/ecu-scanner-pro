import 'package:ecu_scanner_pro/core/pid.dart';
import 'package:flutter_test/flutter_test.dart';

double d(String id, List<int> b) => allPids.firstWhere((p) => p.id == id).decode(b);

void main() {
  test('rumus PID', () {
    expect(d('0C', [0x1A, 0xF8]), 1726);
    expect(d('0D', [60]), 60);
    expect(d('05', [0x7B]), 83);
    expect(d('06', [0x80]), 0);
    expect(d('42', [0x37, 0xE4]), closeTo(14.308, 0.001));
    expect(d('0E', [0x80]), 0);
  });
  test('request dan prefix', () {
    final p = allPids.first;
    expect(p.request, '010C');
    expect(p.prefix, '410C');
  });
}
