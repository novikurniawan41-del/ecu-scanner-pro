import 'package:ecu_scanner_pro/core/dtc_decoder.dart';
import 'package:ecu_scanner_pro/data/dtc_database.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('dekode P, C, B, U', () {
    expect(DtcDecoder.decode([0x01, 0x71, 0x03, 0x00]), ['P0171', 'P0300']);
    expect(DtcDecoder.decode([0xC1, 0x00]), ['U0100']);
    expect(DtcDecoder.decode([0x41, 0x23]), ['C0123']);
    expect(DtcDecoder.decode([0x81, 0x05]), ['B0105']);
  });
  test('padding 0000 diabaikan, byte ganjil diabaikan', () {
    expect(DtcDecoder.decode([0, 0, 0, 0]), isEmpty);
    expect(DtcDecoder.decode([0x01, 0x33, 0x05]), ['P0133']);
  });
  test('kode khusus pabrikan', () {
    expect(DtcDecoder.isManufacturerSpecific('P1234'), isTrue);
    expect(DtcDecoder.isManufacturerSpecific('P0300'), isFalse);
  });
  test('database dan pencarian', () {
    expect(lookupDtc('P0300').priority, 3);
    expect(lookupDtc('P0304').name, contains('silinder 4'));
    expect(lookupDtc('P1999').name, contains('pabrikan'));
    expect(searchDtc('maf'), isNotEmpty);
    expect(searchDtc(''), isEmpty);
  });
}
