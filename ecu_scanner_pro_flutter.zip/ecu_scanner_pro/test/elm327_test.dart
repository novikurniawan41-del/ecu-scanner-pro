import 'package:ecu_scanner_pro/core/elm327.dart';
import 'package:ecu_scanner_pro/core/obd_exception.dart';
import 'package:ecu_scanner_pro/core/pid.dart';
import 'package:ecu_scanner_pro/core/transport.dart';
import 'package:flutter_test/flutter_test.dart';

class Fake implements ObdTransport {
  final Map<String, String> map;
  Fake(this.map);
  @override
  void Function()? onLost;
  @override
  Future<void> open() async {}
  @override
  Future<void> close() async {}
  @override
  Future<String> send(String c, {Duration timeout = const Duration(seconds: 5)}) async {
    if (map[c] == 'THROW') throw ObdException('Timeout: $c');
    return map[c] ?? (c.startsWith('AT') ? 'OK' : 'NO DATA');
  }
}

void main() {
  group('parseResponse', () {
    test('respons normal', () => expect(Elm327Client.parseResponse('41 0C 1A F8', '410C'), [0x1A, 0xF8]));
    test('SEARCHING dan multi baris', () => expect(Elm327Client.parseResponse('SEARCHING...\r41 0D 3C', '410D'), [0x3C]));
    test('NO DATA', () => expect(Elm327Client.parseResponse('NO DATA', '410C'), isNull));
    test('UNABLE TO CONNECT', () => expect(Elm327Client.parseResponse('UNABLE TO CONNECT', '4100'), isNull));
    test('multi frame VIN', () {
      final b = Elm327Client.parseResponse('014\r0: 49 02 01 31 47 31\r1: 4A 43 35', '490201', join: true);
      expect(String.fromCharCodes(b!), '1G1JC5');
    });
  });

  group('Elm327Client', () {
    final base = {'0100': '41 00 BE 3E B8 11', 'ATDP': 'ISO 15765-4 (CAN 11/500)', 'ATRV': '12.6V'};

    test('init mendeteksi protokol', () async {
      final c = Elm327Client(Fake(base));
      await c.init();
      expect(c.protocol, contains('CAN'));
      expect(c.isCan, isTrue);
    });
    test('init gagal bila protokol tidak dikenali', () async {
      final c = Elm327Client(Fake({'0100': 'UNABLE TO CONNECT'}));
      expect(c.init(), throwsA(isA<ObdException>()));
    });
    test('baca DTC pada CAN membuang byte jumlah', () async {
      final c = Elm327Client(Fake({...base, '03': '43 02 01 71 03 00', '07': 'NO DATA'}));
      await c.init();
      expect(await c.readDtc('03'), ['P0171', 'P0300']);
      expect(await c.readDtc('07'), isEmpty);
    });
    test('baca PID', () async {
      final c = Elm327Client(Fake({...base, '010C': '41 0C 1A F8'}));
      expect(await c.readPid(allPids.first), 1726);
      expect(await c.readPid(allPids[1]), isNull);
    });
    test('clear DTC berhasil dan gagal', () async {
      expect(await Elm327Client(Fake({'04': '44'})).clearDtc(), isTrue);
      expect(await Elm327Client(Fake({'04': 'NO DATA'})).clearDtc(), isFalse);
    });
    test('VIN', () async {
      final c = Elm327Client(Fake({'0902': '014\r0: 49 02 01 31 47 31\r1: 4A 43 35 34 4B 34 38 30 30\r2: 31 32 33 34 35 36 37'}));
      expect((await c.readVin()).length, 17);
    });
    test('VIN tidak didukung', () {
      expect(Elm327Client(Fake({})).readVin(), throwsA(isA<ObdException>()));
    });
    test('koneksi terputus memunculkan error', () {
      expect(Elm327Client(Fake({'010C': 'THROW'})).readPid(allPids.first), throwsA(isA<ObdException>()));
    });
    test('readiness', () {
      final r = Elm327Client.parseReadiness([0x82, 0x07, 0xE5, 0x04]);
      expect(r['Misfire'], 'Ready');
      expect(r['Catalyst'], 'Ready');
      expect(r['EVAP'], 'Not Ready');
      expect(r['Secondary Air'], 'Not Supported');
    });
  });
}
