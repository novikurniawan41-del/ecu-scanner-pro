import 'dart:convert';
import 'dart:io';
import 'package:ecu_scanner_pro/core/elm327.dart';
import 'package:ecu_scanner_pro/core/obd_exception.dart';
import 'package:ecu_scanner_pro/core/transports/wifi_transport.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('WifiTransport + Elm327Client lewat server TCP lokal', () async {
    final server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((c) {
      c.listen((d) {
        final cmd = utf8.decode(d).trim();
        const m = {'0100': '41 00 BE 3E B8 11', 'ATDP': 'ISO 15765-4 (CAN 11/500)', 'ATRV': '12.6V', '010C': '41 0C 1A F8'};
        c.write('${m[cmd] ?? 'OK'}\r\r>');
      });
    });
    final t = WifiTransport(host: '127.0.0.1', port: server.port);
    await t.open();
    final c = Elm327Client(t);
    await c.init();
    expect(c.isCan, isTrue);
    expect(Elm327Client.parseResponse(await t.send('010C'), '410C'), [0x1A, 0xF8]);
    await t.close();
    await server.close();
  });

  test('WifiTransport gagal terhubung memberi ObdException', () {
    expect(WifiTransport(host: '127.0.0.1', port: 1).open(), throwsA(isA<ObdException>()));
  });
}
